// ========== ASISTENCIA.JS - TopLiderCoach HUB ==========

// ¿La sesion ya se ha celebrado? (no cuenta hasta llegar su dia y hora)
function asisSesionYaCelebrada(s) {
    var ahora = new Date();
    var hoyISO = ahora.getFullYear() + '-' + String(ahora.getMonth() + 1).padStart(2, '0') + '-' + String(ahora.getDate()).padStart(2, '0');
    if (s.session_date < hoyISO) return true;
    if (s.session_date > hoyISO) return false;
    if (!s.session_time) return true;
    var hm = String(s.session_time).substring(0, 5);
    var ahoraHM = String(ahora.getHours()).padStart(2, '0') + ':' + String(ahora.getMinutes()).padStart(2, '0');
    return hm <= ahoraHM;
}

function asisFiltrarCelebradas(sesiones) {
    if (!sesiones) return;
    for (var i = sesiones.length - 1; i >= 0; i--) {
        if (!asisSesionYaCelebrada(sesiones[i])) sesiones.splice(i, 1);
    }
}
// Asistencia por rango de fechas, filtro por temporada, bienestar, PDF individual y general

(function() {
    if (document.getElementById('wreg-styles')) return;
    const st = document.createElement('style');
    st.id = 'wreg-styles';
    st.textContent = `
        .wreg-card { background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:14px 16px; margin-bottom:12px; }
        .wreg-top { display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin-bottom:12px; }
        .wreg-nombre { font-size:15px; font-weight:600; color:#1f2937; flex:1; min-width:120px; }
        .wreg-peso { display:flex; flex-direction:column; gap:2px; }
        .wreg-peso label { font-size:11px; color:#6b7280; }
        .wreg-peso input { width:75px; padding:5px 8px; border:1px solid #d1d5db; border-radius:6px; }
        .wreg-escalas { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:14px 18px; margin-bottom:10px; }
        .wreg-item label { font-size:12px; color:#374151; display:flex; justify-content:space-between; margin-bottom:5px; }
        .wreg-item input[type=range] { width:100%; }
        .wreg-item input[type=number] { width:100%; padding:5px 8px; border:1px solid #d1d5db; border-radius:6px; }
        .wreg-val { font-weight:700; color:#1f2937; }
        .wreg-extremos { display:flex; justify-content:space-between; font-size:10px; color:#9ca3af; margin-top:2px; }
        .wreg-grupo { background:#f9fafb; border-radius:8px; padding:10px 12px; margin-bottom:10px; }
        .wreg-grupo label { font-size:12px; color:#374151; display:block; margin-bottom:5px; }
        .wreg-grupo select { width:100%; padding:6px 8px; border:1px solid #d1d5db; border-radius:6px; }
        .wreg-indices { display:flex; gap:20px; border-top:1px solid #e5e7eb; padding-top:10px; font-size:13px; color:#6b7280; }
        .wreg-indices strong { font-size:15px; }
    `;
    document.head.appendChild(st);
})();

// Calcula el indice de bienestar de un registro (media de sueno, fatiga, estres).
// Si no hay ninguno de los tres nuevos, intenta usar el campo viejo wellness (compatibilidad).
function wIndiceBienestar(a) {
    const vals = [a.sueno, a.fatiga, a.estres].filter(v => v !== null && v !== undefined && v !== '');
    if (vals.length > 0) {
        return vals.reduce((s, v) => s + Number(v), 0) / vals.length;
    }
    if (a.wellness !== null && a.wellness !== undefined && a.wellness !== '') {
        return Number(a.wellness);
    }
    return null;
}

function togglePanelAsistencia() {
    var tabPlanificador = document.querySelector('.main-tab.planificador');
    if (tabPlanificador) cambiarModulo('planificador', tabPlanificador);
    var btnAsistencia = document.querySelector('#modulo-planificador .sub-tab:last-child');
    if (btnAsistencia) cambiarSubTab('planificador', 'asistencia', btnAsistencia);
}

registrarSubTab('planificador', 'asistencia', function() {
    initFechasAsistencia();
    cargarAsistenciaRango();
});

registrarInit(function() {
    initFechasAsistencia();
});

// ========== CARGAR TEMPORADAS EN SELECTOR ==========
async function cargarTemporadasAsistencia() {
    const select = document.getElementById('asistencia-temporada');
    if (!select) return;
    
    try {
        const clubInfo = clubData || (clubId ? { id: clubId } : null);
        if (!clubInfo) return;
        
        const { data: temporadas } = await supabaseClient
            .from('seasons')
            .select('id, name, start_date, end_date, is_active')
            .eq('club_id', clubInfo.id)
            .order('start_date', { ascending: false });
        
        if (!temporadas || temporadas.length === 0) {
            select.innerHTML = '<option value="">Sin temporadas</option>';
            return;
        }
        
        select.innerHTML = temporadas.map(t => {
            const selected = t.is_active ? 'selected' : '';
            return '<option value="' + t.id + '" data-start="' + (t.start_date || '') + '" data-end="' + (t.end_date || '') + '" ' + selected + '>' + t.name + (t.is_active ? ' (activa)' : '') + '</option>';
        }).join('');
        
    } catch (e) {
        console.warn('Error cargando temporadas asistencia:', e);
    }
}

// ========== AL CAMBIAR TEMPORADA ==========
function onTemporadaAsistenciaChange() {
    const select = document.getElementById('asistencia-temporada');
    if (!select) return;
    
    const option = select.options[select.selectedIndex];
    if (!option) return;
    
    const startDate = option.getAttribute('data-start');
    const endDate = option.getAttribute('data-end');
    
    const inputInicio = document.getElementById('asistencia-fecha-inicio');
    const inputFin = document.getElementById('asistencia-fecha-fin');
    
    if (startDate && inputInicio) inputInicio.value = startDate;
    if (endDate && inputFin) inputFin.value = endDate;
    
    cargarAsistenciaRango();
}

// ========== HELPER: obtener season_id seleccionada ==========
function getAsistenciaSeasonId() {
    const select = document.getElementById('asistencia-temporada');
    return select ? select.value : null;
}

// ========== INICIALIZAR FECHAS (mes actual por defecto) ==========
async function initFechasAsistencia() {
    await cargarTemporadasAsistencia();
    
    const inputInicio = document.getElementById('asistencia-fecha-inicio');
    const inputFin = document.getElementById('asistencia-fecha-fin');
    if (!inputInicio || !inputFin) return;
    
    // Si hay temporada seleccionada, usar sus fechas
    const select = document.getElementById('asistencia-temporada');
    if (select && select.value) {
        const option = select.options[select.selectedIndex];
        const startDate = option ? option.getAttribute('data-start') : '';
        const endDate = option ? option.getAttribute('data-end') : '';
        if (startDate && endDate) {
            inputInicio.value = startDate;
            inputFin.value = endDate;
            return;
        }
    }
    
    // Fallback: mes actual
    if (!inputInicio.value) {
        const hoy = new Date();
        const primerDia = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
        const ultimoDia = new Date(hoy.getFullYear(), hoy.getMonth() + 1, 0);
        inputInicio.value = primerDia.toISOString().split('T')[0];
        inputFin.value = ultimoDia.toISOString().split('T')[0];
    }
}

// Helpers para obtener fechas del rango
function getFechaInicio() {
    return document.getElementById('asistencia-fecha-inicio')?.value || '';
}
function getFechaFin() {
    return document.getElementById('asistencia-fecha-fin')?.value || '';
}
function getRangoTexto() {
    const ini = getFechaInicio();
    const fin = getFechaFin();
    if (!ini || !fin) return '';
    const fIni = new Date(ini + 'T12:00:00').toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' });
    const fFin = new Date(fin + 'T12:00:00').toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' });
    return fIni + ' — ' + fFin;
}

// ========== CARGAR ASISTENCIA POR RANGO ==========
async function cargarAsistenciaRango() {
    const fechaInicio = getFechaInicio();
    const fechaFin = getFechaFin();
    
    if (!fechaInicio || !fechaFin) {
        showToast('Selecciona fecha de inicio y fin');
        return;
    }
    
    if (fechaInicio > fechaFin) {
        showToast('La fecha de inicio no puede ser posterior a la fecha fin');
        return;
    }
    
    const tbody = document.getElementById('asistencia-tabla-body');
    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;">Cargando...</td></tr>';
    
    try {
        const clubInfo = clubData || (clubId ? { id: clubId } : null);
        if (!clubInfo) throw new Error('Club no encontrado');
        
        // Temporada seleccionada
        var selectedSeasonId = getAsistenciaSeasonId();
        
        // Sesiones en el rango (filtradas por season_id si hay temporada seleccionada)
        var querySesiones = supabaseClient
            .from('training_sessions')
            .select('id, session_date, session_time')
            .eq('club_id', clubInfo.id)
            .gte('session_date', fechaInicio)
            .lte('session_date', fechaFin)
            .order('session_date', { ascending: true });
        
        if (selectedSeasonId) {
            querySesiones = querySesiones.eq('season_id', selectedSeasonId);
        }
        
        const { data: sesiones, error: errSes } = await querySesiones;
        // Contar sesiones celebradas O con asistencia ya registrada (aunque no haya llegado su hora)
        var idsRango = (sesiones || []).map(s => s.id);
        var idsConRegistros = {};
        if (idsRango.length > 0) {
            const { data: regPrevios } = await supabaseClient
                .from('asistencia_sesiones')
                .select('sesion_id')
                .in('sesion_id', idsRango);
            (regPrevios || []).forEach(r => { idsConRegistros[r.sesion_id] = true; });
        }
        for (var i = (sesiones || []).length - 1; i >= 0; i--) {
            if (!asisSesionYaCelebrada(sesiones[i]) && !idsConRegistros[sesiones[i].id]) sesiones.splice(i, 1);
        }
        
        if (errSes) throw errSes;
        
        const totalSesiones = sesiones ? sesiones.length : 0;
        document.getElementById('asistencia-total-sesiones').textContent = totalSesiones;
        
        if (totalSesiones === 0) {
            tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#9ca3af;">No hay sesiones en este periodo</td></tr>';
            document.getElementById('asistencia-promedio').textContent = '0%';
            const elJ = document.getElementById('asistencia-total-jugadores'); if (elJ) elJ.textContent = '0';
            return;
        }
        
        // Jugadores de la temporada seleccionada
        var currentSeasonId = selectedSeasonId || seasonId;
        if (!currentSeasonId) {
            // Fallback: buscar temporada activa
            const { data: tempData } = await supabaseClient
                .from('seasons').select('id').eq('club_id', clubInfo.id).eq('is_active', true).single();
            currentSeasonId = tempData?.id;
        }
        
        if (!currentSeasonId) {
            tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#9ca3af;">No hay temporada activa seleccionada</td></tr>';
            return;
        }
        
        const { data: spData } = await supabaseClient
            .from('season_players')
            .select('player_id, shirt_number, players(id, name, photo_url, position, status, fecha_baja)')
            .eq('season_id', currentSeasonId)
            .order('shirt_number');
        
        const fechaIniRango = getFechaInicio();
        const jugadores = (spData || []).filter(sp => sp.players && !(sp.players.status === 'baja' && sp.players.fecha_baja && sp.players.fecha_baja <= fechaIniRango)).map(sp => ({
            id: sp.players.id,
            name: sp.players.name,
            photo_url: sp.players.photo_url,
            position: sp.players.position,
            status: sp.players.status,
            shirt_number: sp.shirt_number
        }));
        
        if (jugadores.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#9ca3af;">No hay jugadores en la plantilla</td></tr>';
            return;
        }
        
        const elJ = document.getElementById('asistencia-total-jugadores'); 
        if (elJ) elJ.textContent = jugadores.length;
        
        // Asistencias del periodo
        const sesionIds = sesiones.map(s => s.id);
        const { data: asistencias } = await supabaseClient
            .from('asistencia_sesiones')
            .select('*')
            .in('sesion_id', sesionIds);
        
        // Calcular stats por jugador
        let htmlRows = '';
        let totalPorcentaje = 0;
        
        for (const jugador of jugadores) {
            const asistJugador = asistencias ? asistencias.filter(a => a.jugador_id === jugador.id) : [];
            const asistencias_si = asistJugador.filter(a => a.asistio === true).length;
            const porcentaje = totalSesiones > 0 ? Math.round((asistencias_si / totalSesiones) * 100) : 0;
            totalPorcentaje += porcentaje;
            
            const conPeso = asistJugador.filter(a => a.peso);
            const conWellness = asistJugador.map(a => wIndiceBienestar(a)).filter(v => v !== null);
            const conMuscular = asistJugador.filter(a => a.estado_muscular !== null && a.estado_muscular !== undefined);
            
            const promPeso = conPeso.length > 0 ? (conPeso.reduce((s, a) => s + parseFloat(a.peso), 0) / conPeso.length).toFixed(1) : '-';
            const promWellness = conWellness.length > 0 ? (conWellness.reduce((s, v) => s + v, 0) / conWellness.length).toFixed(1) : '-';
            const promMuscular = conMuscular.length > 0 ? (conMuscular.reduce((s, a) => s + a.estado_muscular, 0) / conMuscular.length).toFixed(1) : '-';
            
            const clasePorc = porcentaje >= 80 ? 'porcentaje-alto' : porcentaje >= 50 ? 'porcentaje-medio' : 'porcentaje-bajo';
            
            htmlRows += `
                <tr>
                    <td>
                        <div class="jugador-cell">
                            <div class="jugador-mini-foto">
                                ${jugador.photo_url ? `<img src="${jugador.photo_url}" alt="">` : jugador.name.charAt(0)}
                            </div>
                            <div>
                                <strong>${jugador.name}</strong>
                                <br><small style="color:#6b7280;">#${jugador.shirt_number || '-'} - ${jugador.position || ''}</small>
                            </div>
                        </div>
                    </td>
                    <td>${totalSesiones}</td>
                    <td>${asistencias_si}</td>
                    <td class="${clasePorc}">${porcentaje}%</td>
                    <td>${promPeso} kg</td>
                    <td>${promWellness}</td>
                    <td>${promMuscular}</td>
                    <td>
                        <button class="btn-ver-detalle" onclick="verDetalleJugador('${jugador.id}', '${jugador.name}')">👁 Ver</button>
                        <button class="btn-pdf-jugador" onclick="generarPDFJugador('${jugador.id}')">📄 PDF</button>
                    </td>
                </tr>
            `;
        }
        
        tbody.innerHTML = htmlRows;
        
        const promedioGeneral = jugadores.length > 0 ? Math.round(totalPorcentaje / jugadores.length) : 0;
        document.getElementById('asistencia-promedio').textContent = promedioGeneral + '%';
        
    } catch (error) {
        console.error('Error cargando asistencia:', error);
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#dc2626;">Error al cargar datos</td></tr>';
    }
}

// ========== MODAL ASISTENCIA SESIÓN (sin cambios funcionales) ==========
async function abrirModalAsistenciaSesion(sesionId, esPartido) {
    window.asisEsPartido = !!esPartido;
    sesionAsistenciaActual = sesionId;
    document.getElementById('modal-asistencia-sesion').style.display = 'flex';
    document.getElementById('modal-asistencia-jugadores').innerHTML = '<p style="text-align:center;color:#9ca3af;">Cargando...</p>';
    
    try {
        const { data: sesion } = await supabaseClient
            .from(window.asisEsPartido ? 'matches' : 'training_sessions').select('*').eq('id', sesionId).single();
        if (window.asisEsPartido) { sesion.name = 'Partido vs ' + (sesion.opponent || ''); sesion.session_date = sesion.match_date; sesion.players = sesion.convocados || []; sesion.duration_minutes = 90; }
        
        document.getElementById('asistencia-sesion-nombre').textContent = sesion.name;
        document.getElementById('asistencia-sesion-fecha').textContent = new Date(sesion.session_date + 'T12:00:00').toLocaleDateString('es-ES');
        
        let jugadoresSesion = sesion.players || [];
        // Excluir jugadores en baja si la sesion es igual o posterior a su fecha de baja
        try {
            const idsSes = jugadoresSesion.map(j => j.player_id).filter(Boolean);
            if (idsSes.length) {
                const { data: bajas } = await supabaseClient.from('players').select('id, fecha_baja').in('id', idsSes).eq('status', 'baja');
                const bajaMap = {};
                (bajas || []).forEach(b => { bajaMap[b.id] = b.fecha_baja || '0000-00-00'; });
                jugadoresSesion = jugadoresSesion.filter(j => !(bajaMap[j.player_id] && sesion.session_date >= bajaMap[j.player_id]));
            }
        } catch (eB) { console.warn('Filtro bajas:', eB); }
        if (jugadoresSesion.length === 0) {
            document.getElementById('modal-asistencia-jugadores').innerHTML = '<p style="text-align:center;color:#9ca3af;">No hay jugadores en esta sesión</p>';
            return;
        }
        
        const { data: asistencias } = await supabaseClient
            .from(window.asisEsPartido ? 'asistencia_partidos' : 'asistencia_sesiones').select('*').eq(window.asisEsPartido ? 'partido_id' : 'sesion_id', sesionId);
        
        const asistenciasMap = {};
        (asistencias || []).forEach(a => { asistenciasMap[a.jugador_id] = a; });
        
        const GRUPOS = ['Cuádriceps','Isquiotibiales','Gemelo/Sóleo','Aductor','Glúteo','Psoas/Flexor','Lumbar','Tobillo','Rodilla','Otro'];
        let html = '';
        jugadoresSesion.forEach(j => {
            const asist = asistenciasMap[j.player_id] || {};
            const asistio = asist.asistio !== false;
            const motivo = asist.motivo_ausencia || '';
            const peso = asist.peso || '';
            const sueno = asist.sueno || '';
            const fatiga = asist.fatiga || '';
            const estres = asist.estres || '';
            const horasSueno = asist.horas_sueno || '';
            const rpeVal = (asist.rpe === null || asist.rpe === undefined) ? '' : asist.rpe;
            const muscular = (asist.estado_muscular !== null && asist.estado_muscular !== undefined) ? asist.estado_muscular : '';
            const grupoMuscular = asist.grupo_muscular || '';
            const mostrarGrupo = (muscular !== '' && Number(muscular) >= 4);

            let opcionesGrupo = '<option value="">Grupo afectado...</option>';
            GRUPOS.forEach(g => {
                opcionesGrupo += `<option value="${g}" ${grupoMuscular === g ? 'selected' : ''}>${g}</option>`;
            });

            html += `
                <div class="wreg-card" data-player-id="${j.player_id}" data-sin-datos="${(asist.sueno != null || asist.rpe != null) ? '0' : '1'}" data-reg-por="${asist.registrado_por || ''}" data-reg-en="${asist.registrado_en || ''}" data-rpe-en="${asist.rpe_registrado_en || ''}">
                    <div class="wreg-top">
                        <div class="wreg-nombre">${j.shirt_number || '?'}. ${j.name}</div>
                        <button type="button" class="toggle-asistio ${asistio ? 'si' : 'no'}" onclick="toggleAsistencia(this)">
                            ${asistio ? '✓ Asistió' : '✗ No'}
                        </button>
                        <select class="motivo-select ${asistio ? '' : 'visible'}">
                            <option value="">Motivo...</option>
                            <option value="enfermo" ${motivo === 'enfermo' ? 'selected' : ''}>Enfermo</option>
                            <option value="lesionado" ${motivo === 'lesionado' ? 'selected' : ''}>Lesionado</option>
                            <option value="ausente" ${motivo === 'ausente' ? 'selected' : ''}>Ausente</option>
                            <option value="sancionado" ${motivo === 'sancionado' ? 'selected' : ''}>Sancionado</option>
                        </select>
                        <div class="wreg-peso">
                            <label>⚖️ Peso</label>
                            <input type="number" class="peso-input" placeholder="kg" step="0.1" min="30" max="150" value="${peso}">
                        </div>
                    </div>
                    <div class="wreg-escalas">
                        <div class="wreg-item">
                            <label>😴 Sueño <span class="wreg-val" data-for="sueno">${sueno || '-'}</span></label>
                            <input type="range" class="w-sueno" min="1" max="10" value="${sueno || 5}" oninput="wActualizar(this,'sueno')">
                            <div class="wreg-extremos"><span>1 · Pésimo</span><span>Excelente · 10</span></div>
                        </div>
                        <div class="wreg-item">
                            <label>🔋 Fatiga <span class="wreg-val" data-for="fatiga">${fatiga || '-'}</span></label>
                            <input type="range" class="w-fatiga" min="1" max="10" value="${fatiga || 5}" oninput="wActualizar(this,'fatiga')">
                            <div class="wreg-extremos"><span>1 · Agotado</span><span>Pleno · 10</span></div>
                        </div>
                        <div class="wreg-item">
                            <label>🧠 Estrés <span class="wreg-val" data-for="estres">${estres || '-'}</span></label>
                            <input type="range" class="w-estres" min="1" max="10" value="${estres || 5}" oninput="wActualizar(this,'estres')">
                            <div class="wreg-extremos"><span>1 · Muy estresado</span><span>Relajado · 10</span></div>
                        </div>
                        <div class="wreg-item">
                            <label>💪 Daño muscular <span class="wreg-val wreg-musc" data-for="muscular">${muscular === '' ? '-' : muscular}</span></label>
                            <input type="range" class="w-muscular" min="0" max="10" value="${muscular === '' ? 0 : muscular}" oninput="wActualizarMuscular(this)">
                            <div class="wreg-extremos"><span>0 · Sin daño</span><span>Lesión · 10</span></div>
                        </div>
                        <div class="wreg-item wreg-horas">
                            <label>⏱️ Horas de sueño</label>
                            <input type="number" class="w-horas" placeholder="h" step="0.5" min="0" max="16" value="${horasSueno}">
                        </div>
                        <div class="wreg-item">
                            <label>🏃 RPE (esfuerzo de la sesión) <span class="wreg-val" data-for="rpe">${rpeVal === '' ? '-' : rpeVal}</span></label>
                            <input type="range" class="w-rpe" min="0" max="10" value="${rpeVal === '' ? 0 : rpeVal}" data-set="${rpeVal === '' ? '0' : '1'}" oninput="wActualizarRpe(this)">
                            <div class="wreg-extremos"><span>0 · Descanso</span><span>Máximo · 10</span></div>
                        </div>
                    </div>
                    <div class="wreg-grupo" style="display:${mostrarGrupo ? 'block' : 'none'};">
                        <label>🩹 ¿Qué grupo muscular?</label>
                        <select class="w-grupo">${opcionesGrupo}</select>
                    </div>
                    <div class="wreg-indices">
                        <span>Bienestar: <strong class="w-ib">-</strong></span>
                        <span>Daño: <strong class="w-im">-</strong></span>
                    </div>
                </div>
            `;
        });
        
        const durGuardada = (asistencias || []).map(a => a.duracion_real).find(v => v !== null && v !== undefined);
        const durBar = `
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;background:#eef2ff;border:1px solid #c7d2fe;border-radius:10px;padding:10px 14px;margin-bottom:12px;font-size:13px;color:#3730a3;font-weight:600">
                ⏱️ Duración real de la sesión:
                <input type="number" id="w-duracion-real" min="0" max="240" value="${durGuardada || sesion.duration_minutes || ''}" style="width:70px;padding:6px 8px;border:1px solid #c7d2fe;border-radius:7px;font-size:13px"> min
                <span style="font-weight:400;color:#6b7280;font-size:11px">Se usa para calcular la carga de entrenamiento (RPE × minutos)</span>
            </div>`;
        const barraVistas = '<style>.wvista-btn{background:#f3f4f6;border:1px solid #d1d5db;color:#374151;border-radius:8px;padding:7px 14px;font-size:13px;font-weight:600;cursor:pointer}.wvista-btn.activo{background:#7c3aed;border-color:#7c3aed;color:#fff}</style>' +
            '<div style="display:flex;gap:8px;margin-bottom:12px">' +
            '<button type="button" class="wvista-btn activo" data-v="lista" onclick="wVistaCambiar(\'lista\')">▤ Lista</button>' +
            '<button type="button" class="wvista-btn" data-v="fichas" onclick="wVistaCambiar(\'fichas\')">▦ Fichas</button>' +
            '<button type="button" class="wvista-btn" style="margin-left:auto" onclick="wListaPDF()">📄 PDF</button></div>';
        document.getElementById('modal-asistencia-jugadores').innerHTML = durBar + barraVistas + '<div id="wreg-lista"></div><div id="wreg-fichas" style="display:none">' + html + '</div>';
        document.querySelectorAll('.wreg-card').forEach(c => wCalcularIndices(c));
        document.getElementById('wreg-fichas').addEventListener('input', function(e) {
            const c = e.target.closest('.wreg-card');
            if (c) c.dataset.sinDatos = '0';
        });
        window._wListaOrden = { campo: 'muscular', dir: 'desc' };
        wListaRender();
    } catch (error) {
        console.error('Error cargando asistencia:', error);
        document.getElementById('modal-asistencia-jugadores').innerHTML = '<p style="color:red;">Error al cargar</p>';
    }
}

function toggleAsistencia(btn) {
    const row = btn.closest('.wreg-card');
    const motivoSelect = row.querySelector('.motivo-select');
    if (btn.classList.contains('si')) {
        btn.classList.remove('si'); btn.classList.add('no'); btn.textContent = '✗ No';
        motivoSelect.classList.add('visible');
    } else {
        btn.classList.remove('no'); btn.classList.add('si'); btn.textContent = '✓ Asistió';
        motivoSelect.classList.remove('visible'); motivoSelect.value = '';
    }
}

function mostrarGuiaEscalas() {
    const modalHTML = `
        <div class="modal-overlay" onclick="if(event.target === this) this.remove()" style="z-index:1100;">
            <div class="modal-content" style="max-width: 600px; max-height: 90vh; overflow-y: auto;">
                <div class="modal-header" style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);">
                    <h3 style="color:white;">💪 Guía de Escala - Daño Muscular</h3>
                    <button class="modal-close" onclick="this.closest('.modal-overlay').remove()" style="color:white;">&times;</button>
                </div>
                <div class="modal-body">
                    <div>
                        <p style="font-size:13px;color:#6b7280;margin-bottom:12px;">0 = sin daño · 10 = lesión</p>
                        <table style="width:100%;border-collapse:collapse;font-size:14px;">
                            <tr style="background:#d1fae5;"><td style="padding:10px;border:1px solid #e5e7eb;font-weight:bold;width:60px;text-align:center;">0-3</td><td style="padding:10px;border:1px solid #e5e7eb;"><strong>Sin daño / Leve:</strong> Carga alta OK</td></tr>
                            <tr style="background:#fef9c3;"><td style="padding:10px;border:1px solid #e5e7eb;font-weight:bold;text-align:center;">4-5</td><td style="padding:10px;border:1px solid #e5e7eb;"><strong>Moderado:</strong> Carga alta OK con cuidado</td></tr>
                            <tr style="background:#fed7aa;"><td style="padding:10px;border:1px solid #e5e7eb;font-weight:bold;text-align:center;">6-7</td><td style="padding:10px;border:1px solid #e5e7eb;"><strong>Alto:</strong> Limitar intensidad</td></tr>
                            <tr style="background:#fecaca;"><td style="padding:10px;border:1px solid #e5e7eb;font-weight:bold;text-align:center;">8-9</td><td style="padding:10px;border:1px solid #e5e7eb;"><strong>Muy alto:</strong> Riesgo de lesión</td></tr>
                            <tr style="background:#ef4444;color:white;"><td style="padding:10px;border:1px solid #e5e7eb;font-weight:bold;text-align:center;">10</td><td style="padding:10px;border:1px solid #e5e7eb;"><strong>LESIÓN MUSCULAR</strong></td></tr>
                        </table>
                        <p style="font-size:13px;color:#6b7280;margin-top:14px;">A partir de <strong>4</strong> se debe indicar el grupo muscular afectado.</p>
                    </div>
                </div>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHTML);
}

function cerrarModalAsistenciaSesion() {
    document.getElementById('modal-asistencia-sesion').style.display = 'none';
    sesionAsistenciaActual = null;
}

async function guardarAsistenciaSesion() {
    if (!sesionAsistenciaActual) return;
    const rows = document.querySelectorAll('.wreg-card');
    const registros = [];
    rows.forEach(row => {
        const asistio = row.querySelector('.toggle-asistio').classList.contains('si');
        const muscVal = parseInt(row.querySelector('.w-muscular').value);
        registros.push({
            [window.asisEsPartido ? 'partido_id' : 'sesion_id']: sesionAsistenciaActual,
            jugador_id: row.dataset.playerId,
            asistio: asistio,
            motivo_ausencia: asistio ? null : (row.querySelector('.motivo-select').value || null),
            peso: parseFloat(row.querySelector('.peso-input').value) || null,
            sueno: parseInt(row.querySelector('.w-sueno').value) || null,
            fatiga: parseInt(row.querySelector('.w-fatiga').value) || null,
            estres: parseInt(row.querySelector('.w-estres').value) || null,
            estado_muscular: isNaN(muscVal) ? null : muscVal,
            grupo_muscular: (muscVal >= 4) ? (row.querySelector('.w-grupo').value || null) : null,
            horas_sueno: parseFloat(row.querySelector('.w-horas').value) || null,
            rpe: (function() {
                const inp = row.querySelector('.w-rpe');
                if (!inp || inp.dataset.set !== '1') return null;
                const v = parseInt(inp.value);
                return isNaN(v) ? null : v;
            })(),
            duracion_real: (function() {
                const d = parseInt((document.getElementById('w-duracion-real') || {}).value);
                return isNaN(d) ? null : d;
            })(),
            registrado_por: (row.dataset.regPor === 'jugador') ? 'jugador' : 'staff',
            registrado_en: (row.dataset.regPor === 'jugador' && row.dataset.regEn) ? row.dataset.regEn : new Date().toISOString(),
            rpe_registrado_en: row.dataset.rpeEn || null
        });
    });
    try {
        const asisTabla = window.asisEsPartido ? 'asistencia_partidos' : 'asistencia_sesiones';
        await supabaseClient.from(asisTabla).delete().eq(window.asisEsPartido ? 'partido_id' : 'sesion_id', sesionAsistenciaActual);
        const { error } = await supabaseClient.from(asisTabla).insert(registros);
        if (error) throw error;
        showToast('Asistencia y wellness guardados correctamente');
        cerrarModalAsistenciaSesion();
    } catch (error) {
        console.error('Error guardando asistencia:', error);
        showToast('Error al guardar: ' + error.message);
    }
}

function wVistaCambiar(v) {
    document.getElementById('wreg-lista').style.display = v === 'lista' ? 'block' : 'none';
    document.getElementById('wreg-fichas').style.display = v === 'lista' ? 'none' : 'block';
    document.querySelectorAll('.wvista-btn').forEach(b => b.classList.toggle('activo', b.dataset.v === v));
    if (v === 'lista') wListaRender();
}

function wListaLeerCards() {
    const filas = [];
    document.querySelectorAll('.wreg-card').forEach(card => {
        const sinDatos = card.dataset.sinDatos === '1';
        const rpeInp = card.querySelector('.w-rpe');
        const f = {
            id: card.dataset.playerId,
            nombre: card.querySelector('.wreg-nombre').textContent,
            asistio: card.querySelector('.toggle-asistio').classList.contains('si'),
            motivo: card.querySelector('.motivo-select').value || '',
            sinDatos: sinDatos,
            sueno: sinDatos ? null : Number(card.querySelector('.w-sueno').value),
            fatiga: sinDatos ? null : Number(card.querySelector('.w-fatiga').value),
            estres: sinDatos ? null : Number(card.querySelector('.w-estres').value),
            muscular: sinDatos ? null : Number(card.querySelector('.w-muscular').value),
            horas: sinDatos ? null : (parseFloat(card.querySelector('.w-horas').value) || null),
            peso: (function(){ const pi = card.querySelector('.peso-input'); return pi ? (parseFloat(pi.value) || null) : null; })(),
            rpe: (sinDatos || rpeInp.dataset.set !== '1') ? null : Number(rpeInp.value),
            grupo: card.querySelector('.w-grupo').value || '',
            envio: (card.dataset.regPor === 'jugador' && card.dataset.regEn) ? new Date(card.dataset.regEn).getTime() : null,
            rpeEnvio: card.dataset.rpeEn ? new Date(card.dataset.rpeEn).getTime() : null
        };
        f.bienestar = (f.sueno != null) ? Number(((f.sueno + f.fatiga + f.estres) / 3).toFixed(1)) : null;
        filas.push(f);
    });
    return filas;
}

function wListaColor(campo, v) {
    if (v === null || v === undefined || isNaN(v)) return '#9ca3af';
    if (campo === 'peso') return '#1f2937';
    if (campo === 'muscular') return v <= 3 ? '#10b981' : v <= 5 ? '#d97706' : v <= 7 ? '#ea580c' : '#dc2626';
    if (campo === 'rpe') return v >= 8 ? '#ea580c' : v >= 6 ? '#d97706' : '#3b82f6';
    return v >= 7 ? '#10b981' : v >= 5 ? '#d97706' : '#dc2626';
}

function wListaOrdenar(campo) {
    const o = window._wListaOrden || (window._wListaOrden = { campo: 'muscular', dir: 'desc' });
    if (o.campo === campo) o.dir = (o.dir === 'desc' ? 'asc' : 'desc');
    else { o.campo = campo; o.dir = campo === 'nombre' ? 'asc' : 'desc'; }
    wListaRender();
}

function wListaIrAFicha(playerId) {
    wVistaCambiar('fichas');
    const card = document.querySelector('.wreg-card[data-player-id="' + playerId + '"]');
    if (card) {
        card.scrollIntoView({ behavior: 'smooth', block: 'center' });
        card.style.outline = '2px solid #7c3aed';
        setTimeout(function() { card.style.outline = ''; }, 1600);
    }
}

function wListaRender() {
    const cont = document.getElementById('wreg-lista');
    if (!cont) return;
    const o = window._wListaOrden || (window._wListaOrden = { campo: 'muscular', dir: 'desc' });
    const filas = wListaLeerCards();

    const conDatos = filas.filter(f => !f.sinDatos);
    const sinDatos = filas.filter(f => f.sinDatos);
    const ausentes = filas.filter(f => !f.asistio).length;

    const mul = o.dir === 'desc' ? -1 : 1;
    conDatos.sort(function(a, b) {
        if (o.campo === 'nombre') return mul * a.nombre.localeCompare(b.nombre, 'es');
        const va = a[o.campo], vb = b[o.campo];
        if (va == null && vb == null) return 0;
        if (va == null) return 1;
        if (vb == null) return -1;
        return mul * (va - vb);
    });
    sinDatos.sort(function(a, b) { return a.nombre.localeCompare(b.nombre, 'es'); });

    const COLS = [
        ['nombre', 'Jugador'], ['sueno', '😴 Sueño'], ['fatiga', '🔋 Fatiga'], ['estres', '🧠 Estrés'],
        ['muscular', '💪 Daño'], ['horas', '⏱️ Horas'], ['peso', '⚖️ Peso'], ['rpe', '🏃 RPE'], ['bienestar', '💚 Bienestar'], ['envio', '🕐 Envío']
    ];
    let head = '<tr><th style="padding:8px 6px;text-align:center;font-size:11px;color:#6b7280">Asist.</th>';
    COLS.forEach(function(c) {
        const flecha = o.campo === c[0] ? (o.dir === 'desc' ? ' ▼' : ' ▲') : '';
        const alin = c[0] === 'nombre' ? 'left' : 'center';
        head += '<th onclick="wListaOrdenar(\'' + c[0] + '\')" style="padding:8px 6px;text-align:' + alin + ';font-size:11px;color:#374151;cursor:pointer;white-space:nowrap;user-select:none">' + c[1] + flecha + '</th>';
    });
    head += '</tr>';

    function celda(campo, v, extra) {
        const txt = (v === null || v === undefined) ? '—' : v;
        return '<td style="padding:7px 6px;text-align:center;font-weight:700;color:' + wListaColor(campo, v) + '">' + txt + (extra || '') + '</td>';
    }

    function horaEnvio(millis) {
        if (millis == null) return null;
        const d = new Date(millis);
        return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
    }

    function celdaEnvio(f) {
        const h = horaEnvio(f.envio);
        if (h === null) return '<td style="padding:7px 6px;text-align:center;color:#9ca3af">—</td>';
        return '<td style="padding:7px 6px;text-align:center;font-weight:600;color:#1f2937">' + h + '</td>';
    }

    function fila(f, gris) {
        const asistTxt = f.asistio ? '<span style="color:#10b981;font-weight:700">✓</span>'
            : '<span style="color:#dc2626;font-weight:700">✗</span>' + (f.motivo ? '<div style="font-size:10px;color:#9ca3af">' + f.motivo + '</div>' : '');
        const badge = f.sinDatos ? ' <span style="background:#f3f4f6;color:#9ca3af;border-radius:999px;padding:1px 8px;font-size:10px;font-weight:700">Sin datos</span>' : '';
        const grupoTxt = (f.muscular != null && f.muscular >= 4 && f.grupo) ? '<div style="font-size:10px;color:#ea580c;font-weight:600">' + f.grupo + '</div>' : '';
        const rpeHoraTxt = (f.rpe != null && f.rpeEnvio != null) ? '<div style="font-size:10px;color:#7c3aed;font-weight:600">' + horaEnvio(f.rpeEnvio) + '</div>' : '';
        return '<tr onclick="wListaIrAFicha(\'' + f.id + '\')" style="border-top:1px solid #f3f4f6;cursor:pointer;' + (gris ? 'opacity:0.55;background:#fafafa' : '') + '">' +
            '<td style="padding:7px 6px;text-align:center">' + asistTxt + '</td>' +
            '<td style="padding:7px 6px;font-weight:600;color:#1f2937;font-size:13px;white-space:nowrap">' + f.nombre + badge + '</td>' +
            celda('sueno', f.sueno) + celda('fatiga', f.fatiga) + celda('estres', f.estres) +
            celda('muscular', f.muscular, grupoTxt) + celda('horas', f.horas) + celda('peso', f.peso) + celda('rpe', f.rpe, rpeHoraTxt) + celda('bienestar', f.bienestar) + celdaEnvio(f) +
            '</tr>';
    }

    let cuerpo = '';
    conDatos.forEach(function(f) { cuerpo += fila(f, false); });
    sinDatos.forEach(function(f) { cuerpo += fila(f, true); });

    cont.innerHTML =
        '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;font-size:12px;font-weight:600">' +
            '<span style="background:#d1fae5;color:#065f46;border-radius:999px;padding:3px 10px">✅ ' + conDatos.length + ' con datos</span>' +
            '<span style="background:#f3f4f6;color:#6b7280;border-radius:999px;padding:3px 10px">⚠️ ' + sinDatos.length + ' sin datos</span>' +
            '<span style="background:#fee2e2;color:#991b1b;border-radius:999px;padding:3px 10px">✗ ' + ausentes + ' ausentes</span>' +
        '</div>' +
        '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;background:#fff;font-size:13px">' +
            '<thead style="background:#f9fafb">' + head + '</thead><tbody>' + cuerpo + '</tbody>' +
        '</table></div>' +
        '<p style="font-size:11px;color:#9ca3af;margin-top:8px">Clic en una cabecera para ordenar · Clic en una fila para abrir su ficha</p>';
}

function wListaPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const o = window._wListaOrden || { campo: 'muscular', dir: 'desc' };
    const filas = wListaLeerCards();
    const conDatos = filas.filter(f => !f.sinDatos);
    const sinDatos = filas.filter(f => f.sinDatos);
    const mul = o.dir === 'desc' ? -1 : 1;
    conDatos.sort(function(a, b) {
        if (o.campo === 'nombre') return mul * a.nombre.localeCompare(b.nombre, 'es');
        const va = a[o.campo], vb = b[o.campo];
        if (va == null && vb == null) return 0;
        if (va == null) return 1;
        if (vb == null) return -1;
        return mul * (va - vb);
    });
    sinDatos.sort(function(a, b) { return a.nombre.localeCompare(b.nombre, 'es'); });
    const todas = conDatos.concat(sinDatos);
    const nombreSesion = (document.getElementById('asistencia-sesion-nombre') || {}).textContent || 'Sesion';
    const fechaSesion = (document.getElementById('asistencia-sesion-fecha') || {}).textContent || '';
    doc.setFontSize(15); doc.setFont('helvetica', 'bold'); doc.setTextColor(15, 23, 42);
    doc.text('Registro de asistencia y bienestar', 14, 16);
    doc.setFontSize(11); doc.setFont('helvetica', 'normal'); doc.setTextColor(75, 85, 99);
    doc.text(nombreSesion + ' - ' + fechaSesion, 14, 23);
    doc.setFontSize(9);
    doc.text(conDatos.length + ' con datos  ·  ' + sinDatos.length + ' sin datos  ·  ' + filas.filter(f => !f.asistio).length + ' ausentes', 14, 29);
    const body = todas.map(function(f) {
        const v = function(x) { return (x === null || x === undefined) ? '-' : String(x); };
        return [
            f.asistio ? 'Si' : ('No' + (f.motivo ? ' (' + f.motivo + ')' : '')),
            f.nombre + (f.sinDatos ? ' (sin datos)' : ''),
            v(f.sueno), v(f.fatiga), v(f.estres),
            v(f.muscular) + ((f.muscular != null && f.muscular >= 4 && f.grupo) ? ' ' + f.grupo : ''),
            v(f.horas), v(f.peso), v(f.rpe) + ((f.rpe != null && f.rpeEnvio != null) ? (function() { const d = new Date(f.rpeEnvio); return ' (' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0') + ')'; })() : ''), v(f.bienestar),
            (function() { if (f.envio == null) return '-'; const d = new Date(f.envio); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); })()
        ];
    });
    doc.autoTable({
        startY: 34,
        head: [['Asist.', 'Jugador', 'Sueño', 'Fatiga', 'Estrés', 'Daño', 'Horas', 'Peso', 'RPE', 'Bienestar', 'Envío']],
        body: body,
        theme: 'grid',
        styles: { fontSize: 8.5, cellPadding: 2, halign: 'center' },
        headStyles: { fillColor: [124, 58, 237], textColor: 255, fontStyle: 'bold' },
        columnStyles: { 1: { halign: 'left', fontStyle: 'bold' } },
        didParseCell: function(data) {
            if (data.section !== 'body') return;
            const f = todas[data.row.index];
            if (!f) return;
            if (f.sinDatos) { data.cell.styles.textColor = [156, 163, 175]; return; }
            const mapa = { 2: ['sueno', f.sueno], 3: ['fatiga', f.fatiga], 4: ['estres', f.estres], 5: ['muscular', f.muscular], 8: ['rpe', f.rpe], 9: ['bienestar', f.bienestar] };
            const m = mapa[data.column.index];
            if (m && m[1] != null) {
                const hex = wListaColor(m[0], m[1]);
                data.cell.styles.textColor = [parseInt(hex.substr(1, 2), 16), parseInt(hex.substr(3, 2), 16), parseInt(hex.substr(5, 2), 16)];
                data.cell.styles.fontStyle = 'bold';
            }
            if (data.column.index === 0) data.cell.styles.textColor = f.asistio ? [16, 185, 129] : [220, 38, 38];
        }
    });
    doc.setFontSize(7); doc.setTextColor(156, 163, 175);
    doc.text('TopLiderCoach HUB  |  toplidercoach.com', 14, doc.internal.pageSize.getHeight() - 8);
    doc.save('Asistencia_' + nombreSesion.replace(/[^a-zA-Z0-9 ]/g, '').replace(/\s+/g, '_') + '.pdf');
}

function wActualizar(input, campo) {
    const card = input.closest('.wreg-card');
    const span = card.querySelector(`.wreg-val[data-for="${campo}"]`);
    if (span) span.textContent = input.value;
    wCalcularIndices(card);
}

function wActualizarMuscular(input) {
    const card = input.closest('.wreg-card');
    const val = Number(input.value);
    const span = card.querySelector('.wreg-val[data-for="muscular"]');
    if (span) {
        span.textContent = val;
        if (val <= 3) span.style.color = '#10b981';
        else if (val <= 5) span.style.color = '#d97706';
        else if (val <= 7) span.style.color = '#ea580c';
        else span.style.color = '#dc2626';
    }
    const grupo = card.querySelector('.wreg-grupo');
    if (grupo) grupo.style.display = (val >= 4) ? 'block' : 'none';
    wCalcularIndices(card);
}

function wCalcularIndices(card) {
    const sueno = Number(card.querySelector('.w-sueno').value);
    const fatiga = Number(card.querySelector('.w-fatiga').value);
    const estres = Number(card.querySelector('.w-estres').value);
    const musc = Number(card.querySelector('.w-muscular').value);

    const ib = ((sueno + fatiga + estres) / 3);
    const ibSpan = card.querySelector('.w-ib');
    if (ibSpan) {
        ibSpan.textContent = ib.toFixed(1);
        if (ib >= 7) ibSpan.style.color = '#10b981';
        else if (ib >= 5) ibSpan.style.color = '#d97706';
        else ibSpan.style.color = '#dc2626';
    }

    const imSpan = card.querySelector('.w-im');
    if (imSpan) {
        imSpan.textContent = musc;
        if (musc <= 3) imSpan.style.color = '#10b981';
        else if (musc <= 5) imSpan.style.color = '#d97706';
        else if (musc <= 7) imSpan.style.color = '#ea580c';
        else imSpan.style.color = '#dc2626';
    }
}

// ========== VER DETALLE JUGADOR ==========
async function verDetalleJugador(jugadorId, nombreJugador) {
    const fechaInicio = getFechaInicio();
    const fechaFin = getFechaFin();
    var selectedSeasonId = getAsistenciaSeasonId();
    
    try {
        const clubInfo = clubData || (clubId ? { id: clubId } : null);
        
        var queryDetalle = supabaseClient
            .from('training_sessions').select('id, name, session_date, session_time')
            .eq('club_id', clubInfo.id).gte('session_date', fechaInicio).lte('session_date', fechaFin)
            .order('session_date', { ascending: true });
        
        if (selectedSeasonId) {
            queryDetalle = queryDetalle.eq('season_id', selectedSeasonId);
        }
        
        const { data: sesiones } = await queryDetalle;
        asisFiltrarCelebradas(sesiones);
        
        const sesionIds = sesiones ? sesiones.map(s => s.id) : [];
        const { data: asistencias } = await supabaseClient
            .from('asistencia_sesiones').select('*').eq('jugador_id', jugadorId).in('sesion_id', sesionIds);
        
        let htmlHistorial = '';
        for (const sesion of sesiones || []) {
            const asist = asistencias ? asistencias.find(a => a.sesion_id === sesion.id) : null;
            const fechaFormato = new Date(sesion.session_date + 'T12:00:00').toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric', month: 'short' });
            
            if (asist && asist.asistio === true) {
                const ibHist = wIndiceBienestar(asist);
                htmlHistorial += `<div class="historial-sesion-row asistio"><div><span class="historial-fecha">${fechaFormato}</span> - ${sesion.name}</div><div class="historial-datos"><span>✅ Asistió</span>${asist.peso ? `<span>⚖️ ${asist.peso}kg</span>` : ''}${ibHist !== null ? `<span>💚 ${ibHist.toFixed(1)}/10</span>` : ''}${(asist.estado_muscular !== null && asist.estado_muscular !== undefined) ? `<span>💪 ${asist.estado_muscular}/10</span>` : ''}</div></div>`;
            } else if (asist && asist.asistio === false) {
                htmlHistorial += `<div class="historial-sesion-row no-asistio"><div><span class="historial-fecha">${fechaFormato}</span> - ${sesion.name}</div><div><span class="historial-motivo">${asist.motivo_ausencia || 'Sin motivo'}</span></div></div>`;
            } else {
                htmlHistorial += `<div class="historial-sesion-row" style="border-left:4px solid #9ca3af;"><div><span class="historial-fecha">${fechaFormato}</span> - ${sesion.name}</div><div style="color:#9ca3af;">Sin registrar</div></div>`;
            }
        }
        if (!htmlHistorial) htmlHistorial = '<p style="text-align:center;color:#9ca3af;">No hay sesiones en este periodo</p>';
        
        const modalHTML = `
            <div class="modal-overlay" onclick="if(event.target === this) this.remove()">
                <div class="modal-content" style="max-width:600px;">
                    <div class="modal-header"><h3>📊 Detalle de ${nombreJugador}</h3><button class="modal-close" onclick="this.closest('.modal-overlay').remove()">&times;</button></div>
                    <div class="modal-body">
                        <p style="margin-bottom:15px;color:#6b7280;">Periodo: <strong>${getRangoTexto()}</strong></p>
                        <div class="detalle-asistencia-historial">${htmlHistorial}</div>
                    </div>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHTML);
    } catch (error) {
        console.error('Error:', error);
        showToast('Error al cargar detalle');
    }
}

// ========== PDF INDIVIDUAL JUGADOR ==========
async function generarPDFJugador(jugadorId) {
    const fechaInicio = getFechaInicio();
    const fechaFin = getFechaFin();
    var selectedSeasonId = getAsistenciaSeasonId();
    
    try {
        const { data: jugador } = await supabaseClient.from('players').select('*').eq('id', jugadorId).single();
        if (!jugador) { showToast('Jugador no encontrado'); return; }
        
        const clubInfo = clubData || (clubId ? { id: clubId } : null);
        
        var queryPDF = supabaseClient
            .from('training_sessions').select('id, name, session_date, session_time')
            .eq('club_id', clubInfo.id).gte('session_date', fechaInicio).lte('session_date', fechaFin)
            .order('session_date', { ascending: true });
        
        if (selectedSeasonId) {
            queryPDF = queryPDF.eq('season_id', selectedSeasonId);
        }
        
        const { data: sesiones } = await queryPDF;
        asisFiltrarCelebradas(sesiones);
        
        const sesionIds = sesiones ? sesiones.map(s => s.id) : [];
        const { data: asistencias } = await supabaseClient
            .from('asistencia_sesiones').select('*').eq('jugador_id', jugadorId).in('sesion_id', sesionIds);
        
        const totalSesiones = sesiones ? sesiones.length : 0;
        const asistio = asistencias ? asistencias.filter(a => a.asistio === true).length : 0;
        const faltas = asistencias ? asistencias.filter(a => a.asistio === false).length : 0;
        const porcentaje = totalSesiones > 0 ? Math.round((asistio / totalSesiones) * 100) : 0;
        
        const conPeso = asistencias ? asistencias.filter(a => a.peso) : [];
        const conWellness = asistencias ? asistencias.map(a => wIndiceBienestar(a)).filter(v => v !== null) : [];
        const conMuscular = asistencias ? asistencias.filter(a => a.estado_muscular !== null && a.estado_muscular !== undefined) : [];
        const promPeso = conPeso.length > 0 ? (conPeso.reduce((s, a) => s + parseFloat(a.peso), 0) / conPeso.length).toFixed(1) : '-';
        const promWellness = conWellness.length > 0 ? (conWellness.reduce((s, v) => s + v, 0) / conWellness.length).toFixed(1) : '-';
        const promMuscular = conMuscular.length > 0 ? (conMuscular.reduce((s, a) => s + a.estado_muscular, 0) / conMuscular.length).toFixed(1) : '-';
        
        const motivos = {};
        if (asistencias) asistencias.filter(a => !a.asistio && a.motivo_ausencia).forEach(a => { motivos[a.motivo_ausencia] = (motivos[a.motivo_ausencia] || 0) + 1; });
        
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const rangoTexto = getRangoTexto();
        
        // HEADER
        doc.setFillColor(15, 23, 42); doc.rect(0, 0, 210, 50, 'F');
        doc.setFillColor(251, 191, 36); doc.rect(0, 50, 210, 3, 'F');
        if (clubInfo.logo_url) { try { doc.addImage(clubInfo.logo_url, 'PNG', 12, 8, 32, 32); } catch(e) { doc.setFillColor(251,191,36); doc.circle(28,24,16,'F'); doc.setTextColor(15,23,42); doc.setFontSize(16); doc.setFont('helvetica','bold'); doc.text(clubInfo.name?clubInfo.name.charAt(0):'C',28,28,{align:'center'}); } }
        else { doc.setFillColor(251,191,36); doc.circle(28,24,16,'F'); doc.setTextColor(15,23,42); doc.setFontSize(16); doc.setFont('helvetica','bold'); doc.text(clubInfo.name?clubInfo.name.charAt(0):'C',28,28,{align:'center'}); }
        
        doc.setTextColor(255,255,255); doc.setFontSize(22); doc.setFont('helvetica','bold');
        doc.text('INFORME DE RENDIMIENTO', 115, 18, {align:'center'});
        doc.setFontSize(11); doc.setFont('helvetica','normal'); doc.setTextColor(203,213,225);
        doc.text('Control de Asistencia y Bienestar', 115, 28, {align:'center'});
        doc.setFontSize(10); doc.setTextColor(251,191,36);
        doc.text(`${clubInfo.name || 'Mi Club'}  |  ${rangoTexto}`, 115, 40, {align:'center'});
        
        let y = 62;
        
        // FICHA JUGADOR
        doc.setFillColor(248,250,252); doc.roundedRect(12,y,186,38,3,3,'F');
        doc.setDrawColor(226,232,240); doc.roundedRect(12,y,186,38,3,3,'S');
        if (jugador.photo_url) { try { doc.addImage(jugador.photo_url, 'JPEG', 18, y+4, 30, 30); } catch(e) { doc.setFillColor(124,58,237); doc.circle(33,y+19,15,'F'); doc.setTextColor(255,255,255); doc.setFontSize(18); doc.setFont('helvetica','bold'); doc.text(jugador.name.charAt(0),33,y+24,{align:'center'}); } }
        else { doc.setFillColor(124,58,237); doc.circle(33,y+19,15,'F'); doc.setTextColor(255,255,255); doc.setFontSize(18); doc.setFont('helvetica','bold'); doc.text(jugador.name.charAt(0),33,y+24,{align:'center'}); }
        
        doc.setTextColor(15,23,42); doc.setFontSize(18); doc.setFont('helvetica','bold');
        doc.text(jugador.name.toUpperCase(), 55, y+14);
        doc.setFontSize(10); doc.setFont('helvetica','normal'); doc.setTextColor(100,116,139);
        doc.text(`Posicion: ${jugador.position || '-'}`, 55, y+24);
        
        const porcColor = porcentaje >= 80 ? [16,185,129] : porcentaje >= 50 ? [245,158,11] : [239,68,68];
        doc.setFillColor(...porcColor); doc.roundedRect(155,y+5,38,28,3,3,'F');
        doc.setTextColor(255,255,255); doc.setFontSize(20); doc.setFont('helvetica','bold');
        doc.text(`${porcentaje}%`, 174, y+23, {align:'center'});
        doc.setFontSize(7); doc.text('ASISTENCIA', 174, y+30, {align:'center'});
        
        y += 48;
        
        // STATS
        doc.setFillColor(124,58,237); doc.roundedRect(12,y,186,9,2,2,'F');
        doc.setTextColor(255,255,255); doc.setFontSize(10); doc.setFont('helvetica','bold');
        doc.text('RESUMEN DE ASISTENCIA', 105, y+6.5, {align:'center'}); y += 14;
        
        const bw = 58, bh = 28;
        doc.setFillColor(241,245,249); doc.roundedRect(12,y,bw,bh,3,3,'F');
        doc.setTextColor(15,23,42); doc.setFontSize(22); doc.setFont('helvetica','bold');
        doc.text(`${totalSesiones}`, 41, y+14, {align:'center'});
        doc.setFontSize(8); doc.setFont('helvetica','normal'); doc.setTextColor(100,116,139);
        doc.text('SESIONES', 41, y+23, {align:'center'});
        
        doc.setFillColor(220,252,231); doc.roundedRect(76,y,bw,bh,3,3,'F');
        doc.setTextColor(22,163,74); doc.setFontSize(22); doc.setFont('helvetica','bold');
        doc.text(`${asistio}`, 105, y+14, {align:'center'});
        doc.setFontSize(8); doc.setFont('helvetica','normal'); doc.text('ASISTENCIAS', 105, y+23, {align:'center'});
        
        doc.setFillColor(254,226,226); doc.roundedRect(140,y,bw,bh,3,3,'F');
        doc.setTextColor(220,38,38); doc.setFontSize(22); doc.setFont('helvetica','bold');
        doc.text(`${faltas}`, 169, y+14, {align:'center'});
        doc.setFontSize(8); doc.setFont('helvetica','normal'); doc.text('AUSENCIAS', 169, y+23, {align:'center'});
        y += 38;
        
        // BIENESTAR
        doc.setFillColor(59,130,246); doc.roundedRect(12,y,186,9,2,2,'F');
        doc.setTextColor(255,255,255); doc.setFontSize(10); doc.setFont('helvetica','bold');
        doc.text('DATOS DE BIENESTAR (Promedios)', 105, y+6.5, {align:'center'}); y += 14;
        
        doc.setFillColor(241,245,249); doc.roundedRect(12,y,bw,bh,3,3,'F');
        doc.setTextColor(15,23,42); doc.setFontSize(18); doc.setFont('helvetica','bold');
        doc.text(`${promPeso}`, 41, y+12, {align:'center'}); doc.setFontSize(10); doc.text('kg', 41, y+20, {align:'center'});
        doc.setFontSize(8); doc.setFont('helvetica','normal'); doc.setTextColor(100,116,139); doc.text('PESO PROM.', 41, y+26, {align:'center'});
        
        const wn = promWellness !== '-' ? parseFloat(promWellness) : 0;
        doc.setFillColor(...(wn >= 7 ? [220,252,231] : wn >= 5 ? [254,249,195] : [254,226,226]));
        doc.roundedRect(76,y,bw,bh,3,3,'F');
        doc.setTextColor(15,23,42); doc.setFontSize(18); doc.setFont('helvetica','bold');
        doc.text(`${promWellness}`, 105, y+12, {align:'center'}); doc.setFontSize(10); doc.text('/10', 105, y+20, {align:'center'});
        doc.setFontSize(8); doc.setFont('helvetica','normal'); doc.setTextColor(100,116,139); doc.text('WELLNESS', 105, y+26, {align:'center'});
        
        const mn = promMuscular !== '-' ? parseFloat(promMuscular) : 10;
        doc.setFillColor(...(mn <= 4 ? [220,252,231] : mn <= 6 ? [254,249,195] : [254,226,226]));
        doc.roundedRect(140,y,bw,bh,3,3,'F');
        doc.setTextColor(15,23,42); doc.setFontSize(18); doc.setFont('helvetica','bold');
        doc.text(`${promMuscular}`, 169, y+12, {align:'center'}); doc.setFontSize(10); doc.text('/10', 169, y+20, {align:'center'});
        doc.setFontSize(8); doc.setFont('helvetica','normal'); doc.setTextColor(100,116,139); doc.text('MUSCULAR', 169, y+26, {align:'center'});
        y += 38;
        
        // HISTORIAL
        doc.setFillColor(71,85,105); doc.roundedRect(12,y,186,9,2,2,'F');
        doc.setTextColor(255,255,255); doc.setFontSize(10); doc.setFont('helvetica','bold');
        doc.text('HISTORIAL DETALLADO', 105, y+6.5, {align:'center'}); y += 14;
        
        doc.setFillColor(241,245,249); doc.rect(12,y,186,8,'F');
        doc.setTextColor(71,85,105); doc.setFontSize(8); doc.setFont('helvetica','bold');
        doc.text('FECHA',18,y+5.5); doc.text('SESION',50,y+5.5); doc.text('ESTADO',115,y+5.5);
        doc.text('PESO',145,y+5.5); doc.text('WELL',163,y+5.5); doc.text('MUSC',180,y+5.5);
        y += 10;
        
        let filaColor = false;
        for (const sesion of sesiones || []) {
            if (y > 270) { doc.addPage(); y = 20; }
            const asist = asistencias ? asistencias.find(a => a.sesion_id === sesion.id) : null;
            const fechaF = new Date(sesion.session_date + 'T12:00:00').toLocaleDateString('es-ES', {day:'2-digit',month:'2-digit'});
            if (filaColor) { doc.setFillColor(248,250,252); doc.rect(12,y-3,186,9,'F'); }
            filaColor = !filaColor;
            doc.setFontSize(9); doc.setFont('helvetica','normal'); doc.setTextColor(15,23,42);
            doc.text(fechaF, 18, y+3); doc.text(sesion.name.substring(0,30), 50, y+3);
            if (asist) {
                if (asist.asistio) { const ibPdf = wIndiceBienestar(asist); doc.setTextColor(22,163,74); doc.text('Asistio',115,y+3); doc.setTextColor(15,23,42); doc.text(asist.peso?`${asist.peso}`:'-',145,y+3); doc.text(ibPdf!==null?`${ibPdf.toFixed(1)}`:'-',165,y+3); doc.text((asist.estado_muscular!==null&&asist.estado_muscular!==undefined)?`${asist.estado_muscular}`:'-',182,y+3); }
                else { doc.setTextColor(220,38,38); doc.text(asist.motivo_ausencia||'Falta',115,y+3); doc.setTextColor(156,163,175); doc.text('-',145,y+3); doc.text('-',165,y+3); doc.text('-',182,y+3); }
            } else { doc.setTextColor(156,163,175); doc.text('Sin registrar',115,y+3); doc.text('-',145,y+3); doc.text('-',165,y+3); doc.text('-',182,y+3); }
            y += 9;
        }
        
        // FOOTER
        doc.setFillColor(15,23,42); doc.rect(0,282,210,15,'F');
        doc.setFillColor(251,191,36); doc.rect(0,282,210,1,'F');
        doc.setTextColor(148,163,184); doc.setFontSize(8); doc.setFont('helvetica','normal');
        doc.text(`Generado el ${new Date().toLocaleDateString('es-ES',{day:'2-digit',month:'long',year:'numeric'})}`, 15, 290);
        doc.setTextColor(251,191,36); doc.setFont('helvetica','bold');
        doc.text('TopLiderCoach HUB', 195, 290, {align:'right'});
        
        doc.save(`Informe_${jugador.name.replace(/\s/g,'_')}_${fechaInicio}_${fechaFin}.pdf`);
    } catch (error) {
        console.error('Error generando PDF:', error);
        showToast('Error al generar el PDF: ' + error.message);
    }
}

// ========== PDF GENERAL PLANTILLA ==========
async function generarPDFPlantillaGeneral() {
    const fechaInicio = getFechaInicio();
    const fechaFin = getFechaFin();
    if (!fechaInicio || !fechaFin) { showToast('Selecciona fechas primero'); return; }
    var selectedSeasonId = getAsistenciaSeasonId();
    
    try {
        const clubInfo = clubData || (clubId ? { id: clubId } : null);
        if (!clubInfo) throw new Error('Club no encontrado');
        
        // Sesiones (filtradas por temporada si hay seleccionada)
        var queryPDFGen = supabaseClient
            .from('training_sessions').select('id, name, session_date, session_time')
            .eq('club_id', clubInfo.id).gte('session_date', fechaInicio).lte('session_date', fechaFin)
            .order('session_date', { ascending: true });
        
        if (selectedSeasonId) {
            queryPDFGen = queryPDFGen.eq('season_id', selectedSeasonId);
        }
        
        const { data: sesiones } = await queryPDFGen;
        asisFiltrarCelebradas(sesiones);
        
        const totalSesiones = sesiones ? sesiones.length : 0;
        if (totalSesiones === 0) { showToast('No hay sesiones en el periodo seleccionado'); return; }
        
        // Jugadores plantilla (de la temporada seleccionada)
        var currentSeasonId = selectedSeasonId || seasonId;
        if (!currentSeasonId) {
            const { data: tempData } = await supabaseClient
                .from('seasons').select('id').eq('club_id', clubInfo.id).eq('is_active', true).single();
            currentSeasonId = tempData?.id;
        }
        if (!currentSeasonId) { showToast('No hay temporada activa'); return; }
        
        const { data: spData } = await supabaseClient
            .from('season_players')
            .select('player_id, shirt_number, players(id, name, photo_url, position, status, fecha_baja)')
            .eq('season_id', currentSeasonId)
            .order('shirt_number');
        
        const fechaIniPdf = getFechaInicio();
        const jugadores = (spData || []).filter(sp => sp.players && !(sp.players.status === 'baja' && sp.players.fecha_baja && sp.players.fecha_baja <= fechaIniPdf)).map(sp => ({
            id: sp.players.id, name: sp.players.name, photo_url: sp.players.photo_url,
            position: sp.players.position, shirt_number: sp.shirt_number
        }));
        
        if (jugadores.length === 0) { showToast('No hay jugadores en la plantilla'); return; }
        
        // Asistencias
        const sesionIds = sesiones.map(s => s.id);
        const { data: asistencias } = await supabaseClient
            .from('asistencia_sesiones').select('*').in('sesion_id', sesionIds);
        
        // Calcular stats por jugador
        const statsJugadores = jugadores.map(j => {
            const asistJ = asistencias ? asistencias.filter(a => a.jugador_id === j.id) : [];
            const si = asistJ.filter(a => a.asistio === true).length;
            const no = asistJ.filter(a => a.asistio === false).length;
            const pct = totalSesiones > 0 ? Math.round((si / totalSesiones) * 100) : 0;
            const cW = asistJ.map(a => wIndiceBienestar(a)).filter(v => v !== null); const cM = asistJ.filter(a => a.estado_muscular !== null && a.estado_muscular !== undefined); const cP = asistJ.filter(a => a.peso);
            return {
                ...j, asistencias: si, ausencias: no, porcentaje: pct,
                promWellness: cW.length > 0 ? (cW.reduce((s,v) => s+v, 0)/cW.length).toFixed(1) : '-',
                promMuscular: cM.length > 0 ? (cM.reduce((s,a) => s+a.estado_muscular, 0)/cM.length).toFixed(1) : '-',
                promPeso: cP.length > 0 ? (cP.reduce((s,a) => s+parseFloat(a.peso), 0)/cP.length).toFixed(1) : '-'
            };
        });
        
        // Ordenar por % asistencia descendente
        statsJugadores.sort((a, b) => b.porcentaje - a.porcentaje);
        
        const promedioGeneral = statsJugadores.length > 0 ? Math.round(statsJugadores.reduce((s,j) => s+j.porcentaje, 0) / statsJugadores.length) : 0;
        
        // GENERAR PDF
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF('landscape');
        const rangoTexto = getRangoTexto();
        
        // HEADER
        doc.setFillColor(15, 23, 42); doc.rect(0, 0, 297, 45, 'F');
        doc.setFillColor(251, 191, 36); doc.rect(0, 45, 297, 3, 'F');
        
        if (clubInfo.logo_url) { try { doc.addImage(clubInfo.logo_url, 'PNG', 12, 6, 30, 30); } catch(e) {} }
        
        doc.setTextColor(255,255,255); doc.setFontSize(24); doc.setFont('helvetica','bold');
        doc.text('INFORME GENERAL DE ASISTENCIA', 148, 16, {align:'center'});
        doc.setFontSize(12); doc.setFont('helvetica','normal'); doc.setTextColor(203,213,225);
        doc.text('Control de Asistencia de la Plantilla', 148, 26, {align:'center'});
        doc.setFontSize(10); doc.setTextColor(251,191,36);
        doc.text(`${clubInfo.name || 'Mi Club'}  |  ${rangoTexto}`, 148, 36, {align:'center'});
        
        let y = 55;
        
        // RESUMEN GENERAL
        doc.setFillColor(124,58,237); doc.roundedRect(10,y,277,9,2,2,'F');
        doc.setTextColor(255,255,255); doc.setFontSize(10); doc.setFont('helvetica','bold');
        doc.text('RESUMEN GENERAL', 148, y+6.5, {align:'center'}); y += 14;
        
        const bw2 = 65, bh2 = 24;
        // Sesiones
        doc.setFillColor(241,245,249); doc.roundedRect(10,y,bw2,bh2,3,3,'F');
        doc.setTextColor(15,23,42); doc.setFontSize(20); doc.setFont('helvetica','bold');
        doc.text(`${totalSesiones}`, 42, y+12, {align:'center'});
        doc.setFontSize(8); doc.setFont('helvetica','normal'); doc.setTextColor(100,116,139);
        doc.text('SESIONES', 42, y+20, {align:'center'});
        
        // Jugadores
        doc.setFillColor(241,245,249); doc.roundedRect(80,y,bw2,bh2,3,3,'F');
        doc.setTextColor(15,23,42); doc.setFontSize(20); doc.setFont('helvetica','bold');
        doc.text(`${jugadores.length}`, 112, y+12, {align:'center'});
        doc.setFontSize(8); doc.setFont('helvetica','normal'); doc.setTextColor(100,116,139);
        doc.text('JUGADORES', 112, y+20, {align:'center'});
        
        // Asistencia media
        const pctColor = promedioGeneral >= 80 ? [16,185,129] : promedioGeneral >= 50 ? [245,158,11] : [239,68,68];
        doc.setFillColor(...pctColor); doc.roundedRect(150,y,bw2,bh2,3,3,'F');
        doc.setTextColor(255,255,255); doc.setFontSize(20); doc.setFont('helvetica','bold');
        doc.text(`${promedioGeneral}%`, 182, y+12, {align:'center'});
        doc.setFontSize(8); doc.text('ASISTENCIA MEDIA', 182, y+20, {align:'center'});
        
        // Periodo
        doc.setFillColor(241,245,249); doc.roundedRect(220,y,67,bh2,3,3,'F');
        doc.setTextColor(15,23,42); doc.setFontSize(9); doc.setFont('helvetica','bold');
        doc.text(rangoTexto, 253, y+14, {align:'center'});
        doc.setFontSize(8); doc.setFont('helvetica','normal'); doc.setTextColor(100,116,139);
        doc.text('PERIODO', 253, y+20, {align:'center'});
        
        y += 32;
        
        // TABLA
        doc.setFillColor(71,85,105); doc.roundedRect(10,y,277,9,2,2,'F');
        doc.setTextColor(255,255,255); doc.setFontSize(10); doc.setFont('helvetica','bold');
        doc.text('DETALLE POR JUGADOR', 148, y+6.5, {align:'center'}); y += 12;
        
        // Cabecera tabla
        doc.setFillColor(241,245,249); doc.rect(10,y,277,8,'F');
        doc.setTextColor(71,85,105); doc.setFontSize(8); doc.setFont('helvetica','bold');
        doc.text('#', 14, y+5.5);
        doc.text('JUGADOR', 24, y+5.5);
        doc.text('POSICIÓN', 90, y+5.5);
        doc.text('SES', 140, y+5.5);
        doc.text('ASIST', 158, y+5.5);
        doc.text('AUS', 178, y+5.5);
        doc.text('%', 196, y+5.5);
        doc.text('PESO', 212, y+5.5);
        doc.text('WELL', 234, y+5.5);
        doc.text('MUSC', 256, y+5.5);
        y += 10;
        
        let filaColor = false;
        for (const j of statsJugadores) {
            if (y > 190) {
                doc.addPage('landscape');
                y = 15;
                doc.setFillColor(241,245,249); doc.rect(10,y,277,8,'F');
                doc.setTextColor(71,85,105); doc.setFontSize(8); doc.setFont('helvetica','bold');
                doc.text('#',14,y+5.5); doc.text('JUGADOR',24,y+5.5); doc.text('POSICIÓN',90,y+5.5);
                doc.text('SES',140,y+5.5); doc.text('ASIST',158,y+5.5); doc.text('AUS',178,y+5.5);
                doc.text('%',196,y+5.5); doc.text('PESO',212,y+5.5); doc.text('WELL',234,y+5.5); doc.text('MUSC',256,y+5.5);
                y += 10;
                filaColor = false;
            }
            
            if (filaColor) { doc.setFillColor(248,250,252); doc.rect(10,y-3,277,9,'F'); }
            filaColor = !filaColor;
            
            // Color % asistencia
            doc.setFontSize(9); doc.setFont('helvetica','normal'); doc.setTextColor(15,23,42);
            doc.text(`${j.shirt_number || '-'}`, 14, y+3);
            doc.text(j.name.substring(0, 28), 24, y+3);
            doc.setTextColor(100,116,139);
            doc.text((j.position || '-').substring(0, 20), 90, y+3);
            doc.setTextColor(15,23,42);
            doc.text(`${totalSesiones}`, 142, y+3);
            doc.setTextColor(22,163,74); doc.text(`${j.asistencias}`, 162, y+3);
            doc.setTextColor(220,38,38); doc.text(`${j.ausencias}`, 180, y+3);
            
            // % con color
            const pc = j.porcentaje;
            if (pc >= 80) doc.setTextColor(22,163,74);
            else if (pc >= 50) doc.setTextColor(245,158,11);
            else doc.setTextColor(220,38,38);
            doc.setFont('helvetica','bold');
            doc.text(`${pc}%`, 196, y+3);
            
            doc.setFont('helvetica','normal'); doc.setTextColor(15,23,42);
            doc.text(`${j.promPeso}`, 214, y+3);
            doc.text(`${j.promWellness}`, 238, y+3);
            doc.text(`${j.promMuscular}`, 260, y+3);
            
            y += 9;
        }
        
        // FOOTER
        const pageH = doc.internal.pageSize.getHeight();
        doc.setFillColor(15,23,42); doc.rect(0, pageH-12, 297, 12, 'F');
        doc.setFillColor(251,191,36); doc.rect(0, pageH-12, 297, 1, 'F');
        doc.setTextColor(148,163,184); doc.setFontSize(8); doc.setFont('helvetica','normal');
        doc.text(`Generado el ${new Date().toLocaleDateString('es-ES',{day:'2-digit',month:'long',year:'numeric'})}`, 15, pageH-4);
        doc.setTextColor(251,191,36); doc.setFont('helvetica','bold');
        doc.text('TopLiderCoach HUB', 282, pageH-4, {align:'right'});
        
        doc.save(`Asistencia_General_${fechaInicio}_${fechaFin}.pdf`);
        
    } catch (error) {
        console.error('Error generando PDF general:', error);
        showToast('Error al generar PDF: ' + error.message);
    }
}
// Actualiza el valor visible del deslizador de RPE y lo marca como registrado
function wActualizarRpe(input) {
    input.dataset.set = '1';
    const card = input.closest('.wreg-card');
    const span = card.querySelector('.wreg-val[data-for="rpe"]');
    if (span) span.textContent = input.value;
}